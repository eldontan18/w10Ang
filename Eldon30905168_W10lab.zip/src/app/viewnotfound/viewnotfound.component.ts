import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewnotfound',
  templateUrl: './viewnotfound.component.html',
  styleUrls: ['./viewnotfound.component.css']
})
export class ViewnotfoundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
